/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Sussy time lmao                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// back_right_motor     motor         11              
// front_right_motor    motor         1               
// back_left_motor      motor         20              
// front_left_motor     motor         9               
// intake               motor         7               
// endgame              motor         19              
// iner                 inertial      12              
// Flywheel             motor_group   2, 3            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  intake.setVelocity(100,percent);
  Flywheel.setVelocity(100,percent);  

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

//settings
double kP = 0.02;
double kI = 0.0;
double kD = 0.0;
double turnkP = 0.08;
double turnkI = 0.0;
double turnkD = 0.0;
double strafekP = 0.08;
double strafekI = 0.0;
double strafekD = 0.0;

//autonomous settings
int desiredValue = 0;
int desiredstrafeValue = 0;
int desiredturnValue = 0;

int error; //SensorValue - DesiredValue : Position 
int prevError = 0; // Position 20ms ago
int derivative; //error - preverror : speed
int totalerror = 0; //totalerror = totalerror + error

int strafeError; //SensorValue - DesiredValue : Position 
int strafePrevError = 0; // Position 20ms ago
int strafeDerivative; //error - preverror : speed
int strafeTotalerror = 0; //totalerror = totalerror + error

int turnError; //SensorValue - DesiredValue : Position 
int turnprevError = 0; // Position 20ms ago
int turnderivative; //error - preverror : speed
int turntotalerror = 0; //totalerror = totalerror + error

bool resetDriveSensors = false;

//variables modified for use
bool enableDrivePID = true;

int drivePID(){
   
  while(enableDrivePID){

    if (resetDriveSensors) {
     resetDriveSensors = false;
     front_left_motor.setPosition(0,degrees);
     front_right_motor.setPosition(0,degrees);
    }
   
   
   
   
   
   
   
   //get the position of each side

   int LeftPosition = front_left_motor.position(degrees);
   int RightPosition = front_right_motor.position(degrees);
   
   ///////////////////////////////////////////////////
   //lateral movement PID
   //////////////////////////////////////////////////////////////////////////////
   //get the average of both sides
   int AveragePosition = (LeftPosition + RightPosition)/2;

   // potential
   error = desiredValue - AveragePosition;
   
   // derivative
   derivative = error - prevError;
   
   //velocity -> position -> absement
   totalerror += error;

   double lateralMotorPower = error * kP + derivative * kD + totalerror * kI;
   ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////
   //lateral movement PID 2
   //////////////////////////////////////////////////////////////////////////////
   //get the average of both sides
   int strafeAveragePosition = (LeftPosition + RightPosition)/2;

   // potential
   strafeError = desiredstrafeValue - strafeAveragePosition;
   
   // derivative
   strafeDerivative = strafeError - strafePrevError;
   
   //velocity -> position -> absement
   strafeTotalerror += strafeError;

   double StrafeMotorPower = strafeError * strafekP + strafeDerivative * strafekD + strafeTotalerror * strafekI;

   ////////////////////////////////////////////////////
   //turning movement PID
   /////////////////////////////////////////
   
   //get the average of both sides
   int turnDifference = iner.heading(degrees);

   // potential
   turnError = desiredturnValue - turnDifference;
   
   // derivative
   turnderivative = turnError - turnprevError;
   
   //velocity -> position -> absement
   turntotalerror += turnError;

   double turnMotorPower = turnError * turnkP + turnderivative * turnkD + turntotalerror * turnkI;
   ////////////////////////////////////////////////////////////////////////////

   front_left_motor.spin(forward, lateralMotorPower + turnMotorPower + StrafeMotorPower, voltageUnits::volt);
   front_right_motor.spin(forward, lateralMotorPower - turnMotorPower - StrafeMotorPower, voltageUnits::volt);
   back_left_motor.spin(forward, lateralMotorPower + turnMotorPower - StrafeMotorPower, voltageUnits::volt);
   back_right_motor.spin(forward, lateralMotorPower - turnMotorPower + StrafeMotorPower, voltageUnits::volt);
   
   
   //code
   prevError = error;
   turnprevError = turnError;
   vex::task::sleep(20);

  }   
    
  return 1;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  

  vex::task amazing(drivePID);
 //example numbers sus
  resetDriveSensors = true;
  desiredValue = 1400; //1450
  desiredstrafeValue = 1000;
  desiredturnValue = 0;
  

  
  vex::task::sleep(1050);

  



  


  
  
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  
  enableDrivePID = false;
  
  ///////////////////////////
  //settings
  ///////////////////////////////////////////////////////
  while (1) {

    //////////////////////////////
    //driver control
    ///////////////////////////////////////////////////////////////////////////////////////////
    
    while(true) {
        
        //Get the raw sums of appropriate joystick axes
        double front_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct)); 
        double back_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double front_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double back_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct));
        
        //Find the largest raw sum or 100
        double max_raw_value = std::max(front_left,std::max(back_left,std::max(front_right,std::max(back_right,100.0))));
        
        //Scale down each value if there was one larger than 100, otherwise leave them alone
        //The largest value will be scaled down to 100, and the others will be reduced by the same factor
        front_left = front_left / max_raw_value * 100;
        back_left = back_left / max_raw_value * 100;
        front_right = front_right / max_raw_value * 100;
        back_right = back_right / max_raw_value * 100;
        
        //Write the scaled sums out to the various motors
        front_left_motor.spin(fwd, front_left, velocityUnits::pct);
        back_left_motor.spin(fwd, back_left, velocityUnits::pct);
        front_right_motor.spin(fwd, front_right, velocityUnits::pct);
        back_right_motor.spin(fwd, back_right, velocityUnits::pct);
    }


    

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
