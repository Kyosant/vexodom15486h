/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Sussy time lmao                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// back_right_motor     motor         11              
// front_right_motor    motor         1               
// back_left_motor      motor         20              
// front_left_motor     motor         9               
// intake               motor         7               
// endgame              motor         19              
// iner                 inertial      12              
// Flywheel             motor_group   2, 3            
// LeftEncoder          encoder       A, B            
// RightEncoder         encoder       C, D            
// HorizontalEncoder    encoder       E, F            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  intake.setVelocity(100,percent);
  Flywheel.setVelocity(100,percent);  

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

//odom
//settings


//Utilize these three variables to make sure they are reading correctly.
//The horizontal encoder should be positive if you push the robot laterally to the right
//The vertical encoders should be positive if you pusht the robot laterally forward
//Rotating the robot clockwise should yield a positive degree value
//NOTE: The recommended position of the vertical encoders(left and right) should be located at center of mass
bool flipLeftEncoder = false;
bool flipRightEncoder = true;
bool flipHorizontalEncoder = true;
bool flipRotations = false;

//This is how many miliseconds every cycle (recommended is 15)
int milisecondStepTime = 15;

//This is something you should utilize to convert the horizontal encoder distance to match the vertical encoder distance
//Grab a ruler, and push the robot 20 inches straight forward, then record the average vertical value (Example: 51269)
//Reset, Grab a ruler, and push the robot 20 inches to the right, then record the horizontal encoder value (Example: 10532)
//You will need to convert it such that the horizontal matches for the same distance, so the multiplier will be horizontal(10532)/vertical(51269)
//And that number will be the ratio (10532/51269 = 0.2054262809885116)
double verticalToHorizontalRatio = 1.0000000;

//Because we can average the vertical encoders while turning, it will not show a change
//But for the horizontal encoders, it will assume the robot is laterally strafing, which is not correct
//We fix this by applying a multiplier compensation such that we will negate it using the inertial sensor
//Reset your robot, make sure everything is calibrated
//Rotate your robot such that the inertial sensor reads 3600 degrees (i.e. rotate the robot 10 times for the sake of accuracy)
//Your horizontal encoder should have a value (Example: 231809)
//Divide that result by 3600 (231809/3600 = 64.3913888), and that number will be the value used
double rotateNegateHorizontalRatio = 50.000000;

//This is utilized to convert the ticks moved to actual inches
//Push the robot 20 inches forward (without turning it or pushing it strafe-wise)
//Get the average reading of the vertical encoders (Example: 253053)
//Divide the reading by 20 (253053/20 = 12,652.65), and put the multipler in this area
//This will convert it to inches
double posTranslationMultiplier = 1;









//Inclusions added manually

// Include additional mathematical operations
#include <cmath>






//Functions added manually

// Waiting function that returns time actually waited (Credit to James Pearman (jpearman on VEXForum - https://www.vexforum.com/t/vexcode-sleep-help/82706/2?u=connor))
uint32_t wait( uint32_t time_mS ) {
    uint64_t start = Brain.Timer.systemHighResolution();
    this_thread::sleep_for(time_mS);
    return (uint32_t)(Brain.Timer.systemHighResolution() - start); 
}
// This converts degrees to radians
double getRadians(int degrees){
  return ( degrees * M_PI ) / 180 ;
}





//Initialized variables for usage

// Include additional mathematical operations
double lastVerticalPosLocal = 0.0;
double lastHorizontalPosLocal = 0.0;
double XPos = 0.0;
double YPos = 0.0;
/////////////////////////////////////////////////////////////////////////
double GoalXpos = 17.78;
double GoalYpos = 17.78; //122.63
/////////////////////////////////////////////////////////////////////////
double strafeVelocity = iner.acceleration(xaxis);

//pid
//settings
double kP = 0.02;
double kI = 0.0;
double kD = 0.0;
double turnkP = 0.08;
double turnkI = 0.0;
double turnkD = 0.0;
double strafekP = 0.08;
double strafekI = 0.0;
double strafekD = 0.0;

//autonomous settings
int desiredValue = 0;
int desiredstrafeValue = 0;
int desiredturnValue = 0;

int error; //SensorValue - DesiredValue : Position 
int prevError = 0; // Position 20ms ago
int derivative; //error - preverror : speed
int totalerror = 0; //totalerror = totalerror + error

int strafeError; //SensorValue - DesiredValue : Position 
int strafePrevError = 0; // Position 20ms ago
int strafeDerivative; //error - preverror : speed
int strafeTotalerror = 0; //totalerror = totalerror + error

int turnError; //SensorValue - DesiredValue : Position 
int turnprevError = 0; // Position 20ms ago
int turnderivative; //error - preverror : speed
int turntotalerror = 0; //totalerror = totalerror + error

bool resetDriveSensors = false;

//variables modified for use
bool enableDrivePID = true;
bool enableOdom = true;
bool enableAimbot = false;
bool enableNormalDrive = true;


int Odom(){
  
  while(enableOdom){

    // Wait an amount of seconds, while returning the actual wait time to the variable "m" 
    //When telling a computer to wait, it may have a load-amount that would result in it yielding earlier or later then the actual time, that's why we do this
    int m = wait(milisecondStepTime);



    /////////////////////////////////////////////////////////////////////////
    //Gets Values of Encoders
    /////////////////////////////////////////////////////////////////////////
    //This gets the position of the sensors (this is local position)
    int leftEnc = LeftEncoder.position(degrees);
    if(flipLeftEncoder) leftEnc *= -1; // If flipLeft, then multiply value by -1

    int rightEnc = RightEncoder.position(degrees);
    if(flipRightEncoder) rightEnc *= -1; // If flipRight, then multiply value by -1

    int horizEnc = HorizontalEncoder.position(degrees);
    if(flipHorizontalEncoder) horizEnc *= -1; // If flipHorizontal, then multiply value by -1

    // Get the rotation of the inertial sensor
    double RobotRotation = iner.rotation();
    if(flipRotations) RobotRotation *= -1;
    /////////////////////////////////////////////////////////////////////////



    /////////////////////////////////////////////////////////////////////////
    //Does quicc maths to find out an accurate encoder readings of local position change
    /////////////////////////////////////////////////////////////////////////
    //This is for the local position of the robot (THIS IS NOT WORLD POSITION)
    double VerticalPosLocal = (leftEnc + rightEnc) / 2.0;
    double HorizontalPosLocal = horizEnc + (RobotRotation * rotateNegateHorizontalRatio);
    /////////////////////////////////////////////////////////////////////////

    //Applies ratio
    HorizontalPosLocal *= verticalToHorizontalRatio;

    //By getting position - lastposition within 20 miliseconds, this will give us velocity
    //Similar to PID alrogithms, this converts position -> Velocity by gettings its derivative through the continuous loop
    double YV = VerticalPosLocal - lastVerticalPosLocal;
    double XV = HorizontalPosLocal - lastHorizontalPosLocal;

    //Do some relatively-complex maths that converts local velocity to world-space velocity. The (m/milisecondStepTime) at the end is a multiplier 
    //that would scale velocity more appropriately due to computer yields (Line 131 explains) If computer is told to wait 2 second and waits 0.75 instead,
    //the multiplier would then scale the velocity to be 0.375 its value (0.75/2 = 0.375)
    double XVelocityWorldSpace = (XV * std::cos(getRadians(-RobotRotation)) - YV * std::sin(getRadians(-RobotRotation))) * (m/milisecondStepTime);
	  double YVelocityWorldSpace = (XV * std::sin(getRadians(RobotRotation)) - YV * std::cos(getRadians(RobotRotation))) * (m/milisecondStepTime);

    //This would give us the X and Y position in world space
    XPos += XVelocityWorldSpace * posTranslationMultiplier;
    YPos += YVelocityWorldSpace * posTranslationMultiplier;

    //This is applied to be utilized 20 miliseconds after
    lastVerticalPosLocal = VerticalPosLocal;
    lastHorizontalPosLocal = HorizontalPosLocal;
  }
  return 1;
}


int drivePID(){
   
  while(enableDrivePID){

    
   
   
   
   
   
   
   
   //get the position of each side

   //int LeftPosition = front_left_motor.position(degrees);
   //int RightPosition = front_right_motor.position(degrees);
   
   ///////////////////////////////////////////////////
   //lateral movement PID
   //////////////////////////////////////////////////////////////////////////////
   //get the average of both sides
   int AveragePosition = XPos; // (LeftPosition + RightPosition)/2

   // potential
   error = desiredValue - AveragePosition;
   
   // derivative
   derivative = error - prevError;
   
   //velocity -> position -> absement
   totalerror += error;

   double lateralMotorPower = error * kP + derivative * kD + totalerror * kI;
   ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////
   //lateral movement PID 2
   //////////////////////////////////////////////////////////////////////////////
   //get the average of both sides
   int strafeAveragePosition = YPos; // BackEncoder

   // potential
   strafeError = desiredstrafeValue - strafeAveragePosition;
   
   // derivative
   strafeDerivative = strafeError - strafePrevError;
   
   //velocity -> position -> absement
   strafeTotalerror += strafeError;

   double StrafeMotorPower = strafeError * strafekP + strafeDerivative * strafekD + strafeTotalerror * strafekI;

   ////////////////////////////////////////////////////
   //turning movement PID
   /////////////////////////////////////////
   
   //get the average of both sides
   int turnDifference = iner.heading(degrees);

   // potential
   turnError = desiredturnValue - turnDifference;
   
   // derivative
   turnderivative = turnError - turnprevError;
   
   //velocity -> position -> absement
   turntotalerror += turnError;

   double turnMotorPower = turnError * turnkP + turnderivative * turnkD + turntotalerror * turnkI;


   /////////////
   double xodom = lateralMotorPower ;
   double yodom = StrafeMotorPower ;
   double odomrotation = turnMotorPower;
   double odomdirection =  atan2(xodom, yodom) + iner.heading(degrees);
   double odomspeed = fmin(1, sqrt(xodom * xodom + yodom * yodom));
    

    

    double lf = odomspeed * sin(odomdirection + M_PI / 4.0) + odomrotation;
    double rf = odomspeed * cos(odomdirection + M_PI / 4.0) - odomrotation;
    double lr = odomspeed * cos(odomdirection + M_PI / 4.0) + odomrotation;
    double rr = odomspeed * sin(odomdirection + M_PI / 4.0) - odomrotation;
   ////////////////////////////////////////////////////////////////////////////

  // front_left_motor.spin(forward, lateralMotorPower + turnMotorPower + StrafeMotorPower, voltageUnits::volt);
  // front_right_motor.spin(forward, lateralMotorPower - turnMotorPower - StrafeMotorPower, voltageUnits::volt);
  // back_left_motor.spin(forward, lateralMotorPower + turnMotorPower - StrafeMotorPower, voltageUnits::volt);
  // back_right_motor.spin(forward, lateralMotorPower - turnMotorPower + StrafeMotorPower, voltageUnits::volt);
   front_left_motor.spin(forward,lf , voltageUnits::volt);
   front_right_motor.spin(forward,rf, voltageUnits::volt);
   back_left_motor.spin(forward,lr , voltageUnits::volt);
   back_right_motor.spin(forward,rr , voltageUnits::volt);
   
   //code
   prevError = error;
   turnprevError = turnError;
   strafePrevError = strafeError;
   vex::task::sleep(20);

  }   
    
  return 1;
}

int Aimbot(){

  while(enableAimbot){
    double HypoAngle = atan( (XPos - GoalXpos) / (YPos - GoalYpos) ); 
    double AimbotAngle = HypoAngle + (strafeVelocity * .432);
    
        double front_left = (double)(Controller1.Axis3.position(pct) + AimbotAngle + Controller1.Axis1.position(pct)); 
        double back_left = (double)(Controller1.Axis3.position(pct) + AimbotAngle - Controller1.Axis1.position(pct));
        double front_right = (double)(Controller1.Axis3.position(pct) - AimbotAngle - Controller1.Axis1.position(pct));
        double back_right = (double)(Controller1.Axis3.position(pct) - AimbotAngle + Controller1.Axis1.position(pct));
        
        //Find the largest raw sum or 100
        double max_raw_value = std::max(front_left,std::max(back_left,std::max(front_right,std::max(back_right,100.0))));
        
        //Scale down each value if there was one larger than 100, otherwise leave them alone
        //The largest value will be scaled down to 100, and the others will be reduced by the same factor
        front_left = front_left / max_raw_value * 100;
        back_left = back_left / max_raw_value * 100;
        front_right = front_right / max_raw_value * 100;
        back_right = back_right / max_raw_value * 100;
        
        //Write the scaled sums out to the various motors
        front_left_motor.spin(fwd, front_left, velocityUnits::pct);
        back_left_motor.spin(fwd, back_left, velocityUnits::pct);
        front_right_motor.spin(fwd, front_right, velocityUnits::pct);
        back_right_motor.spin(fwd, back_right, velocityUnits::pct);
  }
  return 1;

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  

  vex::task amazing(drivePID);
 //example numbers sus
  resetDriveSensors = true;
  desiredValue = 1400; //1450
  desiredstrafeValue = 1000;
  desiredturnValue = 0;
  

  
  vex::task::sleep(1050);
 
  

 
  
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

int normaldrive() {
  while(enableNormalDrive){
      //Get the raw sums of appropriate joystick axes
        double front_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct)); 
        double back_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double front_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double back_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct));
        
        //Find the largest raw sum or 100
        double max_raw_value = std::max(front_left,std::max(back_left,std::max(front_right,std::max(back_right,100.0))));
        
        //Scale down each value if there was one larger than 100, otherwise leave them alone
        //The largest value will be scaled down to 100, and the others will be reduced by the same factor
        front_left = front_left / max_raw_value * 100;
        back_left = back_left / max_raw_value * 100;
        front_right = front_right / max_raw_value * 100;
        back_right = back_right / max_raw_value * 100;
        
        //Write the scaled sums out to the various motors
        front_left_motor.spin(fwd, front_left, velocityUnits::pct);
        back_left_motor.spin(fwd, back_left, velocityUnits::pct);
        front_right_motor.spin(fwd, front_right, velocityUnits::pct);
        back_right_motor.spin(fwd, back_right, velocityUnits::pct);
  }
  return 1;
}


void usercontrol(void) {
  
  enableDrivePID = false;
  
  ///////////////////////////
  //settings
  ///////////////////////////////////////////////////////
  while (1) {

    //////////////////////////////
    //driver control
    ///////////////////////////////////////////////////////////////////////////////////////////
    
    while(true) {

        if(Controller1.ButtonA.pressing()){
          enableNormalDrive = true;
          enableAimbot = false;
        }
         if(Controller1.ButtonB.pressing()){
          enableNormalDrive = false;
          enableAimbot = true;
        }
        /*   
        //Get the raw sums of appropriate joystick axes
        double front_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct)); 
        double back_left = (double)(Controller1.Axis3.position(pct) + Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double front_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) - Controller1.Axis1.position(pct));
        double back_right = (double)(Controller1.Axis3.position(pct) - Controller1.Axis4.position(pct) + Controller1.Axis1.position(pct));
        
        //Find the largest raw sum or 100
        double max_raw_value = std::max(front_left,std::max(back_left,std::max(front_right,std::max(back_right,100.0))));
        
        //Scale down each value if there was one larger than 100, otherwise leave them alone
        //The largest value will be scaled down to 100, and the others will be reduced by the same factor
        front_left = front_left / max_raw_value * 100;
        back_left = back_left / max_raw_value * 100;
        front_right = front_right / max_raw_value * 100;
        back_right = back_right / max_raw_value * 100;
        
        //Write the scaled sums out to the various motors
        front_left_motor.spin(fwd, front_left, velocityUnits::pct);
        back_left_motor.spin(fwd, back_left, velocityUnits::pct);
        front_right_motor.spin(fwd, front_right, velocityUnits::pct);
        back_right_motor.spin(fwd, back_right, velocityUnits::pct);
        */
    }


    

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
